

   1). Drag the Pallet icon into your 
       applications folder

   2). Have fun : )

       Copyright PixelRed
       http://pixelred.github.io